@section('addiitional_button_1')
        <div class="googleTranslateHolder">
            <div id="google_translate_element" style="background-color:#0000;padding: 0px 12px 0px 12px;"></div>
        </div>
    @endsection
    @section('addiitional_button_1_mobile')
        <div class="googleTranslateHolderMobile">
            <div id="google_translate_element" style="background-color:#0000;padding: 0px 12px 0px 12px;"></div>
        </div>
    @endsection