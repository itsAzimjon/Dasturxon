<?php

return [
    'name' => 'Googletranslate'
];
